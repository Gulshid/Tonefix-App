import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get_it/get_it.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tonefix/core/services/history_service.dart';
import 'package:tonefix/core/services/tone_engine.dart';
import 'package:tonefix/core/theme/theme_cubit.dart';
import 'package:tonefix/features/history/bloc/history_bloc.dart';
import 'package:tonefix/features/home/bloc/home_bloc.dart';
import 'package:tonefix/features/tone_rewrite/bloc/tone_rewrite_bloc.dart';

/// Global service locator — mirrors the `sl` pattern from your demo project.
final sl = GetIt.instance;

Future<void> initDependencies() async {
  // ─── External ──────────────────────────────────────────────────────
  final prefs = await SharedPreferences.getInstance();
  sl.registerSingleton<SharedPreferences>(prefs);

  sl.registerSingleton<FirebaseFirestore>(FirebaseFirestore.instance);
  sl.registerSingleton<FirebaseAuth>(FirebaseAuth.instance);

  // ─── Services ─────────────────────────────────────────────────────
  sl.registerLazySingleton<ToneEngine>(
    () => ToneEngine(
      // TODO: Move to flutter_dotenv or --dart-define for production.
      // Get your free key at https://aistudio.google.com/app/apikey
      apiKey: const String.fromEnvironment(
        'GEMINI_API_KEY',
        defaultValue: 'YOUR_GEMINI_API_KEY_HERE',
      ),
    ),
  );

  sl.registerLazySingleton<HistoryService>(
    () => HistoryService(
      firestore: sl<FirebaseFirestore>(),
      auth: sl<FirebaseAuth>(),
    ),
  );

  // ─── Cubits / BLoCs ───────────────────────────────────────────────
  sl.registerFactory<ThemeCubit>(
    () => ThemeCubit(sl<SharedPreferences>()),
  );

  sl.registerFactory<HomeBloc>(
    () => HomeBloc(),
  );

  sl.registerFactory<ToneRewriteBloc>(
    () => ToneRewriteBloc(
      toneEngine: sl<ToneEngine>(),
      historyService: sl<HistoryService>(),
    ),
  );

  sl.registerFactory<HistoryBloc>(
    () => HistoryBloc(historyService: sl<HistoryService>()),
  );

  // Ensure anonymous auth on startup so Firestore rules work
  await sl<HistoryService>().ensureAnonymousAuth();
}
